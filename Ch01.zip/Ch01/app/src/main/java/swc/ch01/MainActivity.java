package swc.ch01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
public class MainActivity extends AppCompatActivity {

    EditText in;
    TextView t;
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        in=(EditText)findViewById(R.id.in);
        t=(TextView)findViewById(R.id.t);
        b1= (Button) findViewById(R.id.b1);
        b2= (Button) findViewById(R.id.b2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                in.setText("");
                t.setText("");
            }
        });

    }
    public void a()
    {
        int num=Integer.parseInt(in.getText().toString());
        double re=num*3.3058;
        t.setText("面積為:"+re+"平方公尺");
    }
}
